"""Rendering helpers for Praecentor."""
